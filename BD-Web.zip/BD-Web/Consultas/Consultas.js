const connection = require('../DataBase/DB')

function getUsuarioById(id,callback){
    const query = 'SELECT * FROM usuarios WHERE id = ?';

    connection.query(query, [id], (err,result)=>{
        if(err){
            return callback(err,null)
        }
        callback(null, result)
    })
}

module.exports = getUsuarioById;