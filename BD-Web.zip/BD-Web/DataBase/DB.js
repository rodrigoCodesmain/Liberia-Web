const mysql = require('mysql');

const connection = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "TiendaLB"
})

connection.connect((err) =>{
    if(err){
        console.error('error al conectarse a la base de datos')
        return;
    }
    console.log('Conexion realizada con exito')
})

module.exports = connection;