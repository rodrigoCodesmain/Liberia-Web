const express = require('express');
const app = express();
const connection = require('./DataBase/DB')
const getUsuarioById = require('./Consultas/Consultas.js')
app.get("/",(req,res) =>{
    res.send('hello word');
})

// connection.query(query, (err, result) => {
//     if (err) {
//         console.error("Error al obtener los datos:", err);
//         return;
//     }
    
//     // Imprimir el resultado en formato JSON para verlo mejor
//     console.log('El resultado es:', JSON.stringify(result));

//     // Verifica si hay datos en el resultado
//     if (result.length > 0) {
//         console.log('Datos del usuario:', result);
//     } else {
//         console.log('No se encontraron usuarios con id = 1');
//     }
// });

app.get("/usuario/:id", (req, res) => {
    const userId = req.params.id;

    getUsuarioById(userId, (err, result) => {
        if (err) {
            console.error("Error al obtener los datos:", err);
            res.status(500).send("Error en la base de datos");
            return;
        }

        if (result.length > 0) {
            res.json(result); // Enviar los resultados como JSON
        } else {
            res.status(404).send("Usuario no encontrado");
        }
    });
});

const puerto = 3000;
app.listen(puerto, () =>{
    console.log("servidor corriendo en el puerto", puerto)
})
